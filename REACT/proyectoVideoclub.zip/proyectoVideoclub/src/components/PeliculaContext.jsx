import { createContext } from 'react';

const PeliculaContext = createContext();

export default PeliculaContext;
